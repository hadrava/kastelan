# Demo script to upload u-boot and/or uClinux to a virgin target for
# testing.
# (c) 2008 Martin Strubel <hackfin@section5.ch>
#
# Only for ICEbear toolchain
#

import time

from bfemu import loadelf
from bfemu import blackfin

def init_ebiu(cpu):
	"Initialize EBIU. You must match these values to your board hardware"
	cpu.setMMR("EBIU_SDGCTL", 0x0091998d)
	cpu.setMMR("EBIU_SDBCTL", 0x0013)
	cpu.setMMR("EBIU_SDRRC", 0x0817)

def restore(cpu, offset, filename):
	"Restore binary image from file to given offset"
	f = open(filename)
	n = 0x20000
	data = f.read(n)
	i = len(data)
	while i > 0:
		cpu.write(offset, data)
		data = f.read(n)
		print "Writing at %08x" % offset
		offset += i
		i = len(data)

def main(loaduboot = 0):

	cpus = blackfin.open("0", 1)

	n = len(cpus)
	print "Number of CPUS:", n
	if n != 1:
		raise SystemError, "Wrong number of cpus"

	c = blackfin.determine(cpus[0])

	c.stop()
	if loaduboot:
		c.reset(3)
		init_ebiu(c)

		prog = loadelf.load_program(c, "/data/src/u-boot/2009R1-RC3/u-boot")
	else:
		# c.reset(3)
		# c.go()
		# time.sleep(0.5)
		# state = c.stop()

		while (c.state()[0] == blackfin.Blackfin.S_RUN):
			print "CPU still running.."
			c.stop()

		restore(c, 0x1000000, "uClinux/images/uImage.initramfs")

	c.go()
	time.sleep(1.0)
	c.stop()
	pc = c.getRegister("RETE")
	print "Program stopped."
	print "PC is at: 0x%08x" % pc
	c.go()
	print "Program running."

# Call main
main(0)


/* Capture from a video4linux camera driver 
 *
 * <hackfin@section5.ch> explicitely adapted to the OV9655 camera chip
 * in UYVY mode
 *
 * */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <termios.h>
#include <linux/videodev.h>

#include "bfin_simple_timer.h"
#include "jpeg.h"

int gpio_export(unsigned gpio);
int gpio_unexport(unsigned gpio);
int gpio_dir_out(unsigned gpio);
int gpio_dir_in(unsigned gpio);
int gpio_value(unsigned gpio, unsigned value);
int ttysetup(int fd);

#define GPIO_DIR_IN  0
#define GPIO_DIR_OUT 1

#define DEVICE_FILE "/dev/video0"
#define WIDTH 320
#define HEIGHT 240
#define DEFAULT_FMT VIDEO_PALETTE_UYVY
#define DEFAULT_LEN 16
#define DEFAULT_RATE 30

// JPG output buffer
unsigned char jpeg_outbuf[0x100000];
unsigned char vbuf[WIDTH*HEIGHT*2];
unsigned char cbuf[255];

struct encoder_context {
    unsigned short width;
    unsigned short height;
    unsigned short pxsize;
    unsigned short size;
} g_context;

/* Video processing */
int encoder_init(unsigned short w, unsigned short h, unsigned short pixsize);
int encoder_exit(void);
int encode(unsigned char *data);

/* console i/o */
long get_cur_ms();
int kbhit();
void nonblock(int);

char pix_buf[(HEIGHT * WIDTH * 2)];

int main ()
{
    int err = -1;
    int done = 0;
    int fd;
    int tmr2, tmr3;
    unsigned char *ptr = NULL;
    
    int error;
    long start_ms = 0, now_ms = 0, offset_ms = 0;

    gpio_export(36);  // left motor direction
    gpio_dir_out(36);
    gpio_export(37);  // right motor direction
    gpio_dir_out(37);
    gpio_export(39);  // left laser
    gpio_dir_out(39);
    gpio_export(41);  // right laser
    gpio_dir_out(41);
    
	tmr2 = open("/dev/timer2", O_RDWR);
	if (!tmr2)
		puts("unable to open timer2!!");
    ioctl(tmr2, BFIN_SIMPLE_TIMER_SET_PERIOD, 1000);  // set period to 1000usec = 1kHz
    ioctl(tmr2, BFIN_SIMPLE_TIMER_SET_WIDTH, 10);  // set width to 10usec = 1% duty cycle
	ioctl(tmr2, BFIN_SIMPLE_TIMER_START, 0);
    gpio_value(36, 1);  // left motor forward
    
 	tmr3 = open("/dev/timer3", O_RDWR);
	if (!tmr3)
		puts("unable to open timer3!!");
    ioctl(tmr3, BFIN_SIMPLE_TIMER_SET_PERIOD, 1000);  // set period to 1000usec = 1kHz
    ioctl(tmr3, BFIN_SIMPLE_TIMER_SET_WIDTH, 10);  // set width to 10usec = 1% duty cycle
	ioctl(tmr3, BFIN_SIMPLE_TIMER_START, 0);
    gpio_value(37, 1);  // right motor forward
    
    start_ms = get_cur_ms();
    encoder_init(WIDTH, HEIGHT, 2);

    nonblock(1);
    do {
        if (!kbhit())
            continue;
        switch (fgetc(stdin)) {
            case 'I':
                ptr = vbuf;
                error = encode(ptr);
                break;
            case 'l':
                gpio_value(39, 1);
                gpio_value(41, 1);
                break;
            case 'L':
                gpio_value(39, 0);
                gpio_value(41, 0);
                break;
            case '2':
                ioctl(tmr2, BFIN_SIMPLE_TIMER_SET_WIDTH, 300); 
                gpio_value(36, 0);
                ioctl(tmr3, BFIN_SIMPLE_TIMER_SET_WIDTH, 400); 
                gpio_value(37, 0);
                break;
            case '4':
                ioctl(tmr2, BFIN_SIMPLE_TIMER_SET_WIDTH, 500); 
                gpio_value(36, 0);
                ioctl(tmr3, BFIN_SIMPLE_TIMER_SET_WIDTH, 550); 
                gpio_value(37, 1);
                break;
            case '5':
                ioctl(tmr2, BFIN_SIMPLE_TIMER_SET_WIDTH, 10); 
                gpio_value(36, 1);
                ioctl(tmr3, BFIN_SIMPLE_TIMER_SET_WIDTH, 10); 
                gpio_value(37, 1);
                break;
            case '6':
                ioctl(tmr2, BFIN_SIMPLE_TIMER_SET_WIDTH, 550); 
                gpio_value(36, 1);
                ioctl(tmr3, BFIN_SIMPLE_TIMER_SET_WIDTH, 500); 
                gpio_value(37, 0);
                break;
            case '8':
                ioctl(tmr2, BFIN_SIMPLE_TIMER_SET_WIDTH, 800); 
                gpio_value(36, 1);
                ioctl(tmr3, BFIN_SIMPLE_TIMER_SET_WIDTH, 700); 
                gpio_value(37, 1);
                break;
            case 0x1B:
                done = 1;
                break;
        }
        fflush(stdin);
    } while (!done);
    encoder_exit();

    return 0;
}

void hexdump(unsigned char *buf, unsigned long n)
{
    int i = 0;
    int c = 0;
    static char str[8];

    while (i < n) {
        sprintf(str, "%02x ", buf[i]);
        printf("%s", str);
        c++;
        if (c == 16) { c = 0; printf("\r\n"); }
        i++;
    }
    if (c)
        printf("\r\n");
}

void encoder_dummy(unsigned char *buf, int ival)
{
    int x, y;
    int val;
    int line = g_context.width / 2;

    unsigned char *p;

    p = buf;
    for (y = 0; y < g_context.height; y++) {
        val = ival;
        for (x = 0; x < line; x++) {
            *p++ = (val + 127) & 0xff; // U
            *p++ = val; // Y
            *p++ = 127; // V
            *p++ = val; // U
            val++;
        }

    }
}

int encoder_init(unsigned short w, unsigned short h, unsigned short pixsize)
{
    g_context.width = w;
    g_context.height = h;
    g_context.size = w * h * pixsize;
    g_context.pxsize = pixsize;

    return 0;
}

int encode(unsigned char *data)
{
    int ix;
    unsigned char *out;
    unsigned long len;
    static int val;
    static char header[32];

    encoder_dummy(data, val);
    val += 10;
    if (val > 250)
        val = 0;

    //printf("Encoding image...\n");
    out = encode_image(data, jpeg_outbuf, 4, FOUR_TWO_TWO,
        g_context.width, g_context.height);

    //printf("done.\n");

    len = (out - jpeg_outbuf);

    sprintf(header, "##IMJ5%c%c%c%c",
        len & 0xff,
        (len >> 8) & 0xff,
        (len >> 16) & 0xff,
        0);
    for (ix=0; ix<10; ix++)
        putchar(header[ix]);
    for (ix=0; ix<len; ix++)
        putchar(jpeg_outbuf[ix]);

    return 0;
}

int encoder_exit(void)
{
    return 0;
}



long get_cur_ms()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (tv.tv_sec * 1000 + tv.tv_usec / 1000);
}

int gpio_export(unsigned gpio)
{
	int fd, len;
	char buf[11];
 
	fd = open("/sys/class/gpio/export", O_WRONLY);
	if (fd < 0) {
		perror("gpio/export");
		return fd;
	}
 
	len = snprintf(buf, sizeof(buf), "%d", gpio);
	write(fd, buf, len);
	close(fd);
 
	return 0;
}
 
int gpio_unexport(unsigned gpio)
{
	int fd, len;
	char buf[11];
 
	fd = open("/sys/class/gpio/unexport", O_WRONLY);
	if (fd < 0) {
		perror("gpio/export");
		return fd;
	}
 
	len = snprintf(buf, sizeof(buf), "%d", gpio);
	write(fd, buf, len);
	close(fd);
	return 0;
}
 
int gpio_dir(unsigned gpio, unsigned dir)
{
	int fd, len;
	char buf[60];
 
	len = snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/direction", gpio);
 
	fd = open(buf, O_WRONLY);
	if (fd < 0) {
		perror("gpio/direction");
		return fd;
	}
 
	if (dir == GPIO_DIR_OUT)
		write(fd, "out", 4);
	else
		write(fd, "in", 3);
 
	close(fd);
	return 0;
}
 
int gpio_dir_out(unsigned gpio)
{
	return gpio_dir(gpio, GPIO_DIR_OUT);
}
 
int gpio_dir_in(unsigned gpio)
{
	return gpio_dir(gpio, GPIO_DIR_IN);
}
 
int gpio_value(unsigned gpio, unsigned value)
{
	int fd, len;
	char buf[60];
 
	len = snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/value", gpio);
 
	fd = open(buf, O_WRONLY);
	if (fd < 0) {
		perror("gpio/value");
		return fd;
	}
 
	if (value)
		write(fd, "1", 2);
	else
		write(fd, "0", 2);
 
	close(fd);
	return 0;
}

int kbhit()
{
    struct timeval tv;
    fd_set fds;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds); //STDIN_FILENO is 0
    select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
    return FD_ISSET(STDIN_FILENO, &fds);
}

void nonblock(int state)
{
    struct termios ittystate;
 
    //get the terminal state
    tcgetattr(STDIN_FILENO, &ittystate);
 
    if (state==1)
    {
        ittystate.c_cc[VMIN] = 1;
        ittystate.c_iflag &= ~(IGNBRK | BRKINT | ICRNL |
                            INLCR | PARMRK | INPCK | ISTRIP | IXON);
        ittystate.c_oflag = 0;
        ittystate.c_lflag &= ~(ECHO | ECHONL | ICANON | IEXTEN | ISIG);
        ittystate.c_cflag &= ~(CSIZE | PARENB);
        ittystate.c_cflag |= CS8;
        ittystate.c_cc[VMIN]  = 1;
        ittystate.c_cc[VTIME] = 0;
    }
    else if (state==0)
    {
        //turn on canonical mode
        ittystate.c_lflag |= ICANON;
        //turn off output processing
        ittystate.c_oflag |= OPOST;
    }
    //set the terminal attributes.
    tcsetattr(STDIN_FILENO, TCSANOW, &ittystate);
}




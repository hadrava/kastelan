/*
 * Simple timer driver
 *
 * Author: (C) 2006 by Axel Weiss (awe@aglaia-gmbh.de)
 *
 * This is a simple char-device interface driver for the bf5xx_timers driver.
 * It primarily serves as an example for how to use the hardware drivers
 * on blackfin, but may also be used as a starting point of development
 * for more sophisticated driver frontends.
 *
 * Behaviour
 * With this driver, a device node /dev/bf5xx_timer[0...] with major number
 * 238 and minor number 0... can be used to access one of blackfin's internal
 * hardware timer. After open(), the timer may be accessed via ioctl:
 *	BFIN_SIMPLE_TIMER_SET_PERIOD: set timer period (in microseconds)
 *	BFIN_SIMPLE_TIMER_START: start timer
 *	BFIN_SIMPLE_TIMER_STOP: stop timer
 *	BFIN_SIMPLE_TIMER_READ: read the numbers of periods (irq-count)
 * This driver enables:
 *	no physical timer output (OUT_DIS is set)
 *	free running from start
 *	timer interrupt, counting
 * The driver opens a (ro) file at /proc/bfin_simple_timer that shows the
 * irq count values for all timers.
 *
 * Licensed under the GPL-2 or later.
 */

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/interrupt.h>
#include <linux/device.h>
#include <asm/gptimers.h>
#include <asm/irq.h>
#include <asm/bfin_simple_timer.h>
#include <asm/bfin-global.h>
#include <asm/portmux.h>

#define TIMER_MAJOR 238
#define DRV_NAME    "bfin_simple_timer"

MODULE_AUTHOR("Axel Weiss <awe@aglaia-gmbh.de>");
MODULE_DESCRIPTION("simple timer char-device interface for Blackfin gptimers");
MODULE_LICENSE("GPL");

static unsigned long isr_count[MAX_BLACKFIN_GPTIMERS];
static const struct {
	unsigned short id, bit;
	unsigned long irqbit;
	int irq;
} timer_code[MAX_BLACKFIN_GPTIMERS] = {
	{TIMER0_id,  TIMER0bit,  TIMER_STATUS_TIMIL0,  IRQ_TIMER0},
	{TIMER1_id,  TIMER1bit,  TIMER_STATUS_TIMIL1,  IRQ_TIMER1},
	{TIMER2_id,  TIMER2bit,  TIMER_STATUS_TIMIL2,  IRQ_TIMER2},
#if (MAX_BLACKFIN_GPTIMERS > 3)
	{TIMER3_id,  TIMER3bit,  TIMER_STATUS_TIMIL3,  IRQ_TIMER3},
	{TIMER4_id,  TIMER4bit,  TIMER_STATUS_TIMIL4,  IRQ_TIMER4},
	{TIMER5_id,  TIMER5bit,  TIMER_STATUS_TIMIL5,  IRQ_TIMER5},
	{TIMER6_id,  TIMER6bit,  TIMER_STATUS_TIMIL6,  IRQ_TIMER6},
	{TIMER7_id,  TIMER7bit,  TIMER_STATUS_TIMIL7,  IRQ_TIMER7},
#endif
#if (MAX_BLACKFIN_GPTIMERS > 8)
	{TIMER8_id,  TIMER8bit,  TIMER_STATUS_TIMIL8,  IRQ_TIMER8},
	{TIMER9_id,  TIMER9bit,  TIMER_STATUS_TIMIL9,  IRQ_TIMER9},
	{TIMER10_id, TIMER10bit, TIMER_STATUS_TIMIL10, IRQ_TIMER10},
#if (MAX_BLACKFIN_GPTIMERS > 11)
	{TIMER11_id, TIMER11bit, TIMER_STATUS_TIMIL11, IRQ_TIMER11},
#endif
#endif
};

static int timer_ioctl(struct inode *inode, struct file *filp, uint cmd, unsigned long arg)
{
	static unsigned long period, width;

	int minor = MINOR(inode->i_rdev);
	switch (cmd) {
	case BFIN_SIMPLE_TIMER_SET_PERIOD:  // set timer period in microseconds
		if (arg < 2) return -EFAULT;
		period = ((get_sclk() / 1000) * arg) / 1000;
		set_gptimer_period(timer_code[minor].id, period);
		//printk("timer_ioctl TIMER_SET_PERIOD: arg=%lu, period=%lu\n", arg, period);
		break;
	case BFIN_SIMPLE_TIMER_SET_WIDTH:   // set timer pulse width in microseconds
		if (arg < 2) return -EFAULT;
		width = ((get_sclk() / 1000) * arg) / 1000;
		if (width > period) return -EFAULT;
		set_gptimer_pwidth(timer_code[minor].id, width);
		//printk("timer_ioctl TIMER_SET_WIDTH: arg=%lu, width=%lu\n", arg, width);
		break;
	case BFIN_SIMPLE_TIMER_START:
		//printk("timer_ioctl TIMER_START: /dev/timer%d\n", minor);
        switch(minor) {
            case 2:
                peripheral_request(P_TMR2, "/dev/timer");
                break;
            case 3:
                peripheral_request(P_TMR3, "/dev/timer");
                break;
            case 4:
                peripheral_request(P_TMR4, "/dev/timer");
                break;
            case 5:
                peripheral_request(P_TMR5, "/dev/timer");
                break;
            case 6:
                peripheral_request(P_TMR6, "/dev/timer");
                break;
            case 7:
                peripheral_request(P_TMR7, "/dev/timer");
                break;
        }
        set_gptimer_config(timer_code[minor].id, PWM_OUT | PERIOD_CNT | PULSE_HI);
        enable_gptimers(timer_code[minor].bit);
		break;
	case BFIN_SIMPLE_TIMER_STOP:
        switch(minor) {
            case 2:
                peripheral_free(P_TMR2);
                break;
            case 3:
                peripheral_free(P_TMR3);
                break;
            case 4:
                peripheral_free(P_TMR4);
                break;
            case 5:
                peripheral_free(P_TMR5);
                break;
            case 6:
                peripheral_free(P_TMR6);
                break;
            case 7:
                peripheral_free(P_TMR7);
                break;
        }
		disable_gptimers(timer_code[minor].bit);
		break;
	case BFIN_SIMPLE_TIMER_READ:
		/* XXX: this should be put_user() */
		*((unsigned long *)arg) = isr_count[minor];
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static irqreturn_t timer_isr(int irq, void *dev_id)
{
	int minor = (int)dev_id;
#if (MAX_BLACKFIN_GPTIMERS > 8)
	int octet = BFIN_TIMER_OCTET(minor);
#else
	int octet = 0;
#endif
	unsigned long state = get_gptimer_status(octet);
	if (state & timer_code[minor].irqbit) {
		set_gptimer_status(octet, timer_code[minor].irqbit);
		++isr_count[minor];
	}
	return IRQ_HANDLED;
}

static int timer_open(struct inode *inode, struct file *filp)
{
	int minor = MINOR(inode->i_rdev);
	int err = 0;
	if (minor >= MAX_BLACKFIN_GPTIMERS)
		return -ENODEV;
	err = request_irq(timer_code[minor].irq, timer_isr, IRQF_DISABLED, DRV_NAME, (void *)minor);
	if (err < 0) {
		printk(KERN_ERR "request_irq(%d) failed\n", timer_code[minor].irq);
		return err;
	}
	set_gptimer_config(timer_code[minor].id, OUT_DIS | PWM_OUT | PERIOD_CNT | IRQ_ENA);
	pr_debug(DRV_NAME ": device(%d) opened\n", minor);
	return 0;
}

static int timer_close(struct inode *inode, struct file *filp)
{
	int minor = MINOR(inode->i_rdev);
	disable_gptimers(timer_code[minor].bit);
	free_irq(timer_code[minor].irq, (void *)minor);
	pr_debug(DRV_NAME ": device(%d) closed\n", minor);
	return 0;
}

static int timer_read_proc(char *buf, char **start, off_t offset, int cnt, int *eof, void *data)
{
	int i, ret = 0;

	for (i = 0; i < MAX_BLACKFIN_GPTIMERS; ++i)
		ret += sprintf(buf + ret, "timer %2d isr count: %lu\n", i, isr_count[i]);

	return ret;
}

static ssize_t timer_status_show(struct class *timer_class, char *buf)
{
	char *p;
	unsigned short i;
	p = buf;

	for (i = 0; i < MAX_BLACKFIN_GPTIMERS; ++i)
		p += sprintf(p, "timer %2d isr count: %lu\n", i, isr_count[i]);

	return p - buf;
}

static struct file_operations fops = {
	.owner   = THIS_MODULE,
	.ioctl   = timer_ioctl,
	.open    = timer_open,
	.release = timer_close,
};

static struct proc_dir_entry *timer_dir_entry;
static struct class *timer_class;
static CLASS_ATTR(status, S_IRUGO, &timer_status_show, NULL);

static int __init timer_initialize(void)
{
	int minor;
	int err;

	err = register_chrdev(TIMER_MAJOR, DRV_NAME, &fops);
	if (err < 0) {
		pr_debug(DRV_NAME ": could not register device %s\n", DRV_NAME);
		return err;
	}

	timer_dir_entry = create_proc_entry(DRV_NAME, 0444, NULL);
	if (timer_dir_entry)
		timer_dir_entry->read_proc = &timer_read_proc;

	timer_class = class_create(THIS_MODULE, "timer");
	err = class_create_file(timer_class, &class_attr_status);
	if (err) {
		remove_proc_entry(DRV_NAME, NULL);
		unregister_chrdev(TIMER_MAJOR, DRV_NAME);
		return err;
	}

	minor = 0;
#ifdef CONFIG_TICK_SOURCE_SYSTMR0
	/* gptimer0 is used to generate the tick interrupt */
	++minor;
#endif
	for (minor = 0; minor < MAX_BLACKFIN_GPTIMERS; minor++)
		device_create(timer_class, NULL, MKDEV(TIMER_MAJOR, minor),
			NULL, "timer%d", minor);

	pr_debug(DRV_NAME ": module loaded\n");
	return 0;
}
module_init(timer_initialize);

static void __exit timer_cleanup(void)
{
	remove_proc_entry(DRV_NAME, NULL);
	unregister_chrdev(TIMER_MAJOR, DRV_NAME);
	pr_debug(DRV_NAME ": module unloaded\n");
}
module_exit(timer_cleanup);
